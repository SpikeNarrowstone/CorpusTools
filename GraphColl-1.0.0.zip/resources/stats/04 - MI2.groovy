

loop = {


    mu2 = (o11 * o11) / e11;

    return Math.log(mu2) / Math.log(2);

}
