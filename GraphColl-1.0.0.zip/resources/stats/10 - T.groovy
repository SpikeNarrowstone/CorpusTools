

loop = {


    return (o11 - e11) / Math.sqrt(o11);

}
