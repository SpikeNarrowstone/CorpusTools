

loop = {



    return o11 / r1 - o21 / r2;


}
