

loop = {


    mu3 = (o11 * o11 * o11) / e11;


    return Math.log(mu3) / Math.log(2);
}
