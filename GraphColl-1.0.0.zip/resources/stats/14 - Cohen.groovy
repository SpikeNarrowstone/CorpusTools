// Normalisation scale
def NORM_SCALE = 100

// Mapping from file to collocation frequency list
def collocationFreqPerFile      = [:];
def collocationOutsidePerFile   = [:];

// Run once before the loop, but after
// all of the non-loop-scope variables have been loaded.
pullup = {

    println "Generating collocation lists per file for token: ${node}..."
    for(f in corpus.getFiles()){

        // For each file, generate a collocation search
        println("Collocating in file '${f}'");
        def collocationSearch       = new CollocationSearch(node, f, left, right, GUIUtils.status);
        collocationFreqPerFile[f]   = collocationSearch.getFrequencyList();

        // Compute outside-window frequency per file by subtracting the collocation's
        // frequency list from the file's
        def outside = new FrequencyList(f.getFrequencyList())
        outside.subtract(collocationSearch.getFrequencyList())
        collocationOutsidePerFile[f] = outside;
    }

}




// Called once for each collocate
loop = {

    // Compute in/out means
    double mean_in  = inner.getNorm(collocate, NORM_SCALE)  / (double)corpus.fileCount();
    double mean_out = outer.getNorm(collocate, NORM_SCALE)  / (double)corpus.fileCount();

    // Compute variance of within-concordance values for a given collocate
    double var_sum_in  = 0d;
    double var_sum_out = 0d;
    for(f in corpus.getFiles()){
        var_sum_in  += (collocationFreqPerFile[f].getNorm(collocate, NORM_SCALE)    - mean_in)  ** 2.0d;
        var_sum_out += (collocationOutsidePerFile[f].getNorm(collocate, NORM_SCALE) - mean_out) ** 2.0d;
    }
    double variance_in  = var_sum_in  / (double)corpus.fileCount();
    double variance_out = var_sum_out / (double)corpus.fileCount();

    // Compute pooled standard dev and store it
    double pooled_stdev = Math.sqrt( 
            (variance_in * inner.n() + variance_out * outer.n()) /
            (inner.n() + outer.n() - 2.0d)
            );

    // Compute cohen and return
    def cohend   = (mean_in - mean_out) / pooled_stdev;

    //out.println("Token: ${collocate}");
    //out.println("Mean /file (inner/outer): ${mean_in}/${mean_out}");
    //out.println("Variance (inner/outer): ${variance_in}/${variance_out}");
    //out.println("pooled sd: ${pooled_stdev}");
    //out.println("cohen's D: ${cohend}");
    //out.println("");

    return cohend;
}
