

loop = {

    // Compute Mu
    mu = o11 / e11;

    // Return log2(mu)
    //
    // Since Java (and thus Groovy) lack a binary log function,
    // use the identity logb(x) = ln(x) / ln(b)
    return (Math.log(mu) / Math.log(2));

}
