
loop = {


    return o11 / e11;

}
