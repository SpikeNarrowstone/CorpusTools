

loop = {


    dice = (2 * o11) / (r1 + c1);

    return 14 + Math.log(dice) / Math.log(2);

}
