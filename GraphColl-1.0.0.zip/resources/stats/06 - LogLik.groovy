// Executed once per word comparison
loop = {


    // Limit ourselves to things with over 5 hits,
    //if o11 < 5
    //	return null;



    double loglik = 0;

    if(o11 > 0 && e11 > 0){
        loglik += o11 * Math.log(o11/e11);
    }else{
        return null;
    }

    if(o21 > 0 && e21 > 0){
        loglik += o21 * Math.log(o21/e21);
    }else{
        return null;
    }

    loglik *= 2;

   

    return loglik;
}


