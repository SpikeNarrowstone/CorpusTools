

loop = {


    return (2 * o11) / (r1 + c1);

}
