

loop = {


    s1 = o11 / c1;
    s2 = o11 / r1;

    return Math.min(s1, s2);

}
