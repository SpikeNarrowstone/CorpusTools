

loop = {


    ratio = (o11 * r2) / (o21 * r1);

    return Math.log(ratio) / Math.log(2);

}


