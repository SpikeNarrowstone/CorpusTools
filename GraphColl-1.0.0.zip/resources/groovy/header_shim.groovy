import static java.lang.Math.*; 
//
// Import the CollocationSearch API
//
// TODO: FIXME: remove this and make it possible
// for scripts to import it.
//
// At the moment the try/catch prevents people from
// running imports, and this is included to allow the
// 'Cohen' effect size script to run.
//
// It's an ugly hack but is neater than other hacks
// until a more fully-featured system of loading stats
// exists.
//
import uk.ac.lancs.cass.graphcoll.model.*;
import uk.ac.lancs.cass.graphcoll.gui.GUIUtils;	// Status bar.
// END OF FIXME

// Extra debug output
/* out.println("Groovy script running."); */

// Set sane defaults
int all_freq, in_freq, out_freq, all_n, in_n, out_n = 0;
String type = "";

// Define sane closure defaults
def pullup      = {};
def loop        = {};
def threshold   = {return true};

// Debug, pullup complete
/* out.println("Pullup done"); */

// Header to try/catch, to define items where
// they can still present an error for the user.
try {

