// You can use all of the variables
// available to statistics, plus 's',
// the value of the statistic.
// 
// Return a truthy value to keep,
// or a falsy one to discard the link.

threshold = {

    // Variables
    // ---------
    // s        : The value of the statistic
    // o11..o22 : Frequencies (see docs)
    // e11..e22 : Expected values (see docs)
    // r1/c1/n  : Row, column, grand totals

    return ( 
            s   >= 6.63 &&    // Stats value > 6.63 (cutoff for loglik)
            c1  >= 5    &&    // Collocate count > 5 in whole corpus
            o11 >= 4          // Collocation count
    );

}
