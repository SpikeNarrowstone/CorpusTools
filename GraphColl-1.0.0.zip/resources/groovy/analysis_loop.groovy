// Virtual definitions (defined in Java prior to pullup:
//
// stats       // The output StatList object
// inner       // The 'within collocation' FrequencyList object
// outer       // The 'outside collocation' FrequencyList object
// all         // The whole-corpus FrequencyList object (in + out)
//
// corpus      // The Corpus object
// left        // The left hand collocation window width
// right       // The right hand collocation window width
// node        // The node type


    // Run any static preparatory stages the statistical
    // method may have defined.
    pullup();


    // Loop over all of the keys and compute statistics for them.
    int iterationCount = 0;
    for (_collocate in all.keys()){
        collocate  = _collocate;

        // Set progress values if progressListener is set.
        iterationCount ++;
        if(_progressListener != null){
            _progressListener.setProgress("Examining collocate: " + collocate, iterationCount);
        }

        // Variable names according to Brezina's pending paper
    /*  o11 = inner.get(collocate);;
        o12 = inner.n() - o11;
        o21 = outer.get(collocate);
        o22 = outer.n() - o21;
        r1  = (use_adjusted_r == true ? ((left + right) * all.get(node)) : all.get(node));
        r2  = outer.n();
        c1  = o11 + o21;
        c2  = o12 + o22;
        n   = r1 + r2;      // == all_n, unless use_adjusted_r == true.
    */
        n   = all.n();
        r1  = (use_adjusted_r == true ? ((left + right) * all.get(node)) : all.get(node));
        c1  = all.get(collocate);
        o11 = inner.get(collocate);
        r2  = n - r1;
        c2 = n - c1;
        o12 = r1 - o11;
        o21 = c1 - o11;
        o22 = r2 - o21;

        // Expected values according to Brezina's pending paper
        e11 = (r1 * c1) / n;
        e12 = (r1 * c2) / n;
        e21 = (r2 * c1) / n;
        e22 = (r2 * c2) / n;
        er1 = r1 / n;
        er2 = r2 / n;
        ec1 = c1 / n;
        ec2 = c2 / n;


        // Invoke the user script
        def _value = loop();
        s = _value;      // alias for use in threshold code
        def threshold_result = threshold();

        // Put the result into a StatList
        if (s != null && s && threshold_result != false)
            stats.put(collocate, _value);
   } // /for


}catch(e){
    // Tell the GroovyComparisonShim that we have failed.
    // The trailing space is to convince it that the string isn't empty even
    // if the message is not set.
    _error = (String)e.getMessage() + " ";

    // Output to the debug log if such a thing is enabled.
    out.println("\n*** Error in Groovy script!");
    out.println("Message: " + e.getMessage());
    out.println("  Cause: " + e.getCause());
    out.println("  Trace: " + e.getStackTrace());
}
